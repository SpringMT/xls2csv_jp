# NAME

xls2csv\_jp - It's new $module

# SYNOPSIS

    use xls2csv_jp;

# DESCRIPTION

xls2csv\_jp is ...

# LICENSE

Copyright (C) haruyama-makoto.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

# AUTHOR

haruyama-makoto <makoto.haruyama@dena.com>
