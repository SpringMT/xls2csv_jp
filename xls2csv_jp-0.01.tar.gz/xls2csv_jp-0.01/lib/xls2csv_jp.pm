package xls2csv_jp;
use 5.008005;
use strict;
use warnings;

our $VERSION = "0.01";



1;
__END__

=encoding utf-8

=head1 NAME

xls2csv_jp - It's new $module

=head1 SYNOPSIS

    use xls2csv_jp;

=head1 DESCRIPTION

xls2csv_jp is ...

=head1 LICENSE

Copyright (C) haruyama-makoto.

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.

=head1 AUTHOR

haruyama-makoto E<lt>makoto.haruyama@dena.comE<gt>

=cut

